#include<iostream>
using namespace std;
class measure{
public:
int height;
int length;
int width;

void setinput(int a,int b,int c){
height=a;
length=b;
width=c;
}
int area(){
return length*width;
}
int volume(){
return height*length*width;
}
};

int main(){
measure obj1;
obj1.setinput(10, 20, 30);
cout << "The inputs: " << obj1.height << obj1.length << obj1.width <<endl;
cout << "The area of rectangle is: " <<obj1.area() <<endl;
cout << "The volume of rectangle is: " <<obj1.volume();
return 0;
}
